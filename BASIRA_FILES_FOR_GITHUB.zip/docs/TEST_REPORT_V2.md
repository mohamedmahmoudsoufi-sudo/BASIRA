# BASIRA v2 — Verification Notes

## Automated test run performed in this review
Command: `node tests/run_tests.js`
Result: **Passed** (script printed `ALL BASIRA v2.0 AUTOMATED TESTS PASSED SUCCESSFULLY.`)

The test file contains two assertions:
1. PII masking: checks a phone, Emirates ID, and IBAN-like string are masked by the test helper.
2. Static URL scoring: checks a sample HTTP URL with a suspicious TLD and keywords receives a score of at least 40.

## What this result does NOT prove
- It does not verify all eight feature areas mentioned in earlier project notes.
- It does not test the OCR flow in a browser, actual uploaded images, UI accessibility, timeline behavior, export/download, or the full app's PII masking toggle.
- It does not establish accuracy, detection rate, or a calibrated risk probability.

## Features visible in source (not independently browser-tested here)
- Client-side OCR integration calls Tesseract.js with Arabic and English.
- Static URL heuristics check protocol, selected suspicious TLDs, keywords, and IP-like addresses; it does not intentionally open the submitted URL.
- Evidence entry and scenario presets; rule-based scoring and timeline rendering.
- PII masking patterns for selected UAE phone, Emirates ID, and IBAN formats.
- JSON export control in the UI.

## Limitations / responsible use
Use synthetic or redacted evidence. Avoid passwords, OTPs, card data, or sensitive personal information. Heuristics may produce false positives and false negatives. BASIRA is a prototype for educational demonstration, not an official fraud determination or professional security service.
