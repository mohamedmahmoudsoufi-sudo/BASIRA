// BASIRA v2.0 Automated Verification Suite
const assert = require('assert');

function maskPII(text) {
  return text
    .replace(/784-\d{4}-\d{7}-\d/g, '[EMIRATES-ID-MASKED]')
    .replace(/(\+971|00971|05)\d{8,9}/g, '[UAE-PHONE-MASKED]')
    .replace(/AE\d{21}/gi, '[UAE-IBAN-MASKED]');
}

function inspectUrlStatic(urlStr) {
  let score = 0;
  if (/\.(xyz|top|icu)/i.test(urlStr)) score += 25;
  if (/^http:\/\//i.test(urlStr)) score += 15;
  return score;
}

// Test 1: PII Masking
const masked = maskPII('رقم الهاتف +971501234567 والهوية 784-1995-1234567-1 والحساب AE070331234567890123456');
assert(!masked.includes('501234567') && !masked.includes('1995') && !masked.includes('AE07'), 'PII Masking test failed');

// Test 2: Static URL Inspector
const uScore = inspectUrlStatic('http://uae-bank-verify.xyz/login');
assert(uScore >= 40, 'Static URL Inspector test failed');

console.log('ALL BASIRA v2.0 AUTOMATED TESTS PASSED SUCCESSFULLY.');
