# BASIRA – بصيرة (MVP v2)
**لا تكتفِ باكتشاف الاحتيال؛ افهم كيف حدث.**

BASIRA is a browser-based prototype for reviewing scam-related evidence and presenting rule-based indicators, a reconstructed sequence, risk signals, and a JSON incident report.

## Included in this repository
- `src/index.html` and `src/app.js`: single-page web prototype and client-side logic.
- `data/`: (reserved for demo data; no dataset is included in this package).
- `tests/run_tests.js`: small Node.js test script covering PII masking and URL score rules.
- `docs/TEST_REPORT_V2.md`: honest verification notes and limits.

## Run
You can open `src/index.html` in a modern browser. For a local server, install Node.js and run:

```bash
npm install
npm start
```

`npm start` uses `serve` through `npx`. Internet access may be needed to download the package and external browser libraries used by the page.

## Run the automated checks
```bash
npm test
```
The current test script contains **2 assertions**. Passing it is not proof that every feature is tested or that all browser interactions work.

## Safety and privacy notes
- URL inspection is static: the prototype does not intentionally navigate to suspicious URLs.
- Risk scoring is heuristic/rule-based and is not a confirmed fraud verdict.
- Use synthetic or redacted evidence for demos. Do not enter passwords, OTPs, card data, or sensitive personal information.
- PII masking can be toggled in the interface and uses limited pattern matching; it is not guaranteed to catch every sensitive value.
- Browser-side OCR depends on Tesseract.js and may require internet access for the library/language data; test this in the target browser.

## Current limitations
- This is an MVP/demo, not an official government, bank, or law-enforcement tool.
- No backend or persistent database is included in this archive.
- Automated tests are limited and do not cover OCR, full UI, timeline rendering, report export, or all masking patterns.
- Do not treat the report's risk score as calibrated probability or a substitute for human review.

## Project structure
```text
BASIRA_COMPLETE_PROJECT_V2/
├── README.md
├── package.json
├── .env.example
├── .gitignore
├── src/
│   ├── index.html
│   └── app.js
├── tests/
│   └── run_tests.js
└── docs/
    └── TEST_REPORT_V2.md
```
